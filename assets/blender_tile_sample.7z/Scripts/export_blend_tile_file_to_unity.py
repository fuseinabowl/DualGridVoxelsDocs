#! python

from argparse import ArgumentParser
import sys

from voxel_collapse.eprint import *
from voxel_collapse.path import *
from voxel_collapse.export_blend_file import export_blend_3d_tile_file


def main(blend_file_path_str : str) -> None:
  export_blend_3d_tile_file(blend_file_path_str)


if __name__ == '__main__':
  parser = ArgumentParser(description='Export a single \'.blend\' tile file from art source to Unity source. Generates the tile variants for all orthogonally adjacent 3D borders on the tile.')
  parser.add_argument('blend_file', type=str, help='The path to the \'.blend\' file to export')
  args = parser.parse_args()

  try:
    main(args.blend_file)
  except Exception as e:
    eprint(str(e))
    sys.exit(1)
