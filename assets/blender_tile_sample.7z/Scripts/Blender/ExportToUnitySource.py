#! bpy

import bpy

import sys
import logging
from argparse import ArgumentParser
from typing import List, Any, Callable


def main(output_file : str) -> None:
  try:
    # if we're already in object mode this will raise an exception
    bpy.ops.object.mode_set(mode='OBJECT')
  except RuntimeError:
    pass

  bpy.ops.object.select_all(action='DESELECT')
  logging.info('selecting objects for export...')
  for blender_object in bpy.context.scene.objects:
    if blender_object.type in ['MESH', 'EMPTY'] :
      blender_object.select_set(True)
  logging.info(f'selected {len(bpy.context.selected_objects)} objects')
  logging.info(f'exporting to {output_file}...')
  bpy.ops.export_scene.fbx(
      filepath=output_file
    , apply_unit_scale=True
    , apply_scale_options='FBX_SCALE_ALL'
    , check_existing=False
    , axis_up='Z'
    , axis_forward='Y'
    , use_selection=True
    , bake_space_transform=True
    , bake_anim=True
    , bake_anim_use_all_actions=True
  )
  logging.info('export complete')


def index_of_first(collection : List[Any], pred : Callable[[Any], bool]) -> int:
  for index, value in enumerate(collection):
    if pred(value):
      return index

  return -1


if __name__ == '__main__':
  parser = ArgumentParser(description='Export a single \'.blend\' file from art source to Unity source within a Blender instance')
  parser.add_argument('output_file', type=str, help='The path to export to')

  all_blender_args = sys.argv
  arg_separator_index = index_of_first(all_blender_args, lambda arg: arg == '--')
  if arg_separator_index == -1:
    logging.error('Blender was called with no arg separator (\'--\') so there was no way to know where this script\'s arguments began')
    sys.exit(-1)

  script_specific_args = all_blender_args[arg_separator_index + 1:]
  args = parser.parse_args(script_specific_args)
  
  main(args.output_file)
