#! bpy

import bpy
import bmesh
import mathutils
import math
from collections import namedtuple

import sys
import logging
import pathlib
import os
from argparse import ArgumentParser
from typing import List, Any, Callable, Iterable


cube_size = 1.0
half_cube_size = cube_size / 2.0


def main(output_path : str) -> None:
  # uncomment the next line to enable logging to the blender-calling console
  turn_on_loud_logging()
  try:
    # if we're already in object mode this will raise an exception
    bpy.ops.object.mode_set(mode='OBJECT')
  except RuntimeError:
    pass

  logging.info('beginning export')
  exportable_models = prepare_for_export()
  export(exportable_models, output_path)
  logging.info('export complete')


def prepare_for_export() -> List[bpy.types.Object]:
  logging.info('preparing models for export')
  world_models = get_all_world_models()
  logging.info('applying modifiers')
  for model in world_models:
    apply_all_modifiers(model)
  logging.info('combining world models')
  single_world_model = combine_world_models(world_models)

  separated_world_models = separate_loose_geometry(single_world_model)

  cached_tile_positioners = get_all_tile_positioners()

  positioner_names = cache_positioner_names_and_rename(cached_tile_positioners)
  separated_world_tiles = [carve_tiles(model, cached_tile_positioners, positioner_names, separation_index) for separation_index, model in enumerate(separated_world_models)]

  for i, world in enumerate(separated_world_tiles):
    logging.info(f'reporting tiles for {i}')

    for tile in world:
      logging.info(f'tile {tile.name} has {len(tile.data.polygons)} faces')

  # polygons get to here fine

  logging.info('joining tiles')
  bpy.ops.object.select_all(action='DESELECT')
  joined_world_tiles = [
    combine_tiles(
      separated_world_tiles[0][tile_index],
      [separated_world_tiles[separated_world_index][tile_index] for separated_world_index in range(1, len(separated_world_models))]
    ) for tile_index in range(len(cached_tile_positioners))
  ]
  logging.info(f'carved {len(joined_world_tiles)} tile(s)')

  return separated_world_tiles[0]


def separate_loose_geometry(model : bpy.types.Object) -> List[bpy.types.Object]:
  select_object(model)
  
  bpy.ops.object.mode_set(mode='EDIT')
  bpy.ops.mesh.separate(type='LOOSE')
  bpy.ops.object.mode_set(mode='OBJECT')

  loose_geometry_objects = list(bpy.context.selected_objects)

  logging.debug('separating geo, reporting number of faces in each separated object:')
  logging.debug(', '.join((str(len(obj.data.polygons)) for obj in loose_geometry_objects)))

  return loose_geometry_objects


def select_object(target : bpy.types.Object) -> None:
  bpy.ops.object.select_all(action='DESELECT')
  target.select_set(True)
  bpy.context.view_layer.objects.active = target


def cache_positioner_names_and_rename(tile_positioners : List[bpy.types.Object]) -> List[str]:
  return [cache_positioner_name_and_rename(positioner) for positioner in tile_positioners]


def cache_positioner_name_and_rename(positioner : bpy.types.Object) -> str:
  tile_name = positioner.name
  positioner.name = tile_name + ' positioner'
  return tile_name


def carve_tiles(model : bpy.types.Object, tile_positioners : List[bpy.types.Object], tile_names : List[str], separation_index : int) -> List[bpy.types.Object]:
  logging.debug(f'carving tiles from {model.name}')
  return [carve_tile(tile_positioner, construct_tile_name(tile_name, separation_index), model) for tile_positioner, tile_name in zip(tile_positioners, tile_names)]


def construct_tile_name(base_name : str, world_index : int) -> str:
  if world_index == 0:
    return base_name
  else:
    return f'{base_name}_{str(world_index)}'


def combine_tiles(root_model : bpy.types.Object, other_models : Iterable[bpy.types.Object]) -> bpy.types.Object:
  logging.info(f'joining root tile {root_model.name}')
  logging.info(f'to other tiles {", ".join((model.name for model in other_models))}')
  populated_other_models = [other_model for other_model in other_models if len(other_model.data.polygons) > 0]
  logging.info(f'total selected objects: {", ".join((model.name for model in populated_other_models))}')
  if len(populated_other_models) > 0:
    bpy.ops.object.select_all(action='DESELECT')
    for model_object in [root_model] + populated_other_models:
      model_object.select_set(True)
    bpy.context.view_layer.objects.active = root_model
    bpy.ops.object.join()
  return root_model


def split_all_normals(single_world_model : bpy.types.Object) -> bpy.types.Object:
  single_world_model.data.calc_normals_split()
  loop_normals = [loop.normal for loop in single_world_model.data.loops]
  bm = bmesh.new()
  bm.from_mesh(single_world_model.data)

  face_cache = [face for face in bm.faces]
  for face in face_cache:
    op_result = bmesh.ops.duplicate(bm, geom=[face])
    generated_face = op_result['face_map'][face]
    for i, original_loop_index in enumerate(loop.index for loop in face.loops):
      logging.debug(f"changing normal from {generated_face.loops[i].vert.normal} to {loop_normals[original_loop_index]}")
      generated_face.loops[i].vert.normal = loop_normals[original_loop_index]

  bmesh.ops.delete(bm, geom=face_cache)

  bm.to_mesh(single_world_model.data)
  bm.free()

  return single_world_model


def get_objects_in_collection(collection_name : str) -> List[bpy.types.Object]:
  root_collection = bpy.context.scene.collection
  collection_list = list(filter(lambda collection: collection.name == collection_name, root_collection.children))
  collection = collection_list[0]
  logging.debug(f'found collection {collection.name}, which has {len(collection.all_objects)} object(s)')
  return [obj for obj in collection.all_objects]


def get_all_world_models() -> List[bpy.types.Object]:
  models_name = 'Models'
  make_collection_selectable(models_name)
  return get_objects_in_collection(models_name)


def get_all_tile_positioners() -> List[bpy.types.Object]:
  positions_name = 'Tile positions'
  make_collection_selectable(positions_name)
  return get_objects_in_collection(positions_name)


def make_collection_selectable(collection_name : str) -> None:
  for view_layer in bpy.context.scene.view_layers:
    recursively_make_collection_visible(view_layer.layer_collection, collection_name)
      
      
def recursively_make_collection_visible(root_collection : bpy.types.LayerCollection, collection_name : str) -> None:
  if root_collection.name == collection_name:
    print(f'{root_collection.name} currently hidden: {root_collection.hide_viewport}')
    root_collection.hide_viewport = False
  
  for child_collection in root_collection.children:
    recursively_make_collection_visible(child_collection, collection_name)


def get_area_from_context(context, area_type):
    area = None
    for a in context.screen.areas:
        if a.type == area_type:
            area = a
            break
    return area


def apply_all_modifiers(target_object : bpy.types.Object) -> None:
  context_override = bpy.context.copy()
  context_override['object'] = target_object
  modifier_names = [modifier.name for modifier in target_object.modifiers]
  for modifier_name in modifier_names:
    logging.debug(f'Applying modifier {modifier_name} to {target_object.name}')
    mod_result = bpy.ops.object.modifier_apply(context_override, modifier=modifier_name)
    assert('FINISHED' in mod_result)

  assert(len(target_object.modifiers) == 0)


def combine_world_models(world_models : List[bpy.types.Object]) -> bpy.types.Object:
  if len(world_models) > 1:
    context_override = bpy.context.copy()
    context_override['selected_objects'] = world_models
    context_override['object'] = world_models[0]
    bpy.ops.object.join(context_override)
  return world_models[0]


def duplicate_world(world : bpy.types.Object) -> bpy.types.Object:
  copied_object = world.copy()
  copied_object.data = copied_object.data.copy()
  bpy.context.collection.objects.link(copied_object)
  return copied_object


def is_face_over_bisect_plane(face, plane_co, plane_no):
  pos = face.calc_center_bounds()
  return (pos - plane_co).dot(plane_no) > 0.0


def carve_tile(positioner : bpy.types.Object, tile_name : str, world : bpy.types.Object) -> bpy.types.Object:
  duplicated_world = duplicate_world(world)
  duplicated_world.name = tile_name
  logging.debug(f'carving tile {tile_name}')

  # carve the duped mesh along +-X, +-Y, +-Z
  location = positioner.location

  bm = bmesh.new()
  bm.from_mesh(duplicated_world.data)

  for carve_direction in [
    mathutils.Vector(( 1.0, 0.0, 0.0)),
    mathutils.Vector((-1.0, 0.0, 0.0)),
    mathutils.Vector(( 0.0, 1.0, 0.0)),
    mathutils.Vector(( 0.0,-1.0, 0.0)),
    mathutils.Vector(( 0.0, 0.0, 1.0)),
    mathutils.Vector(( 0.0, 0.0,-1.0)),
  ]:
    plane_position = (carve_direction * 0.5) * positioner.dimensions + positioner.location - world.location
    plane_normal = carve_direction * -1.0
    result = bmesh.ops.bisect_plane(bm, geom=bm.edges[:] + bm.faces[:], dist=0.001, plane_co=plane_position, plane_no=plane_normal, clear_outer=True, clear_inner=False)
    faces_to_remove = [face for face in bm.faces if not is_face_over_bisect_plane(face, plane_position, plane_normal)]
    bmesh.ops.delete(bm, geom=faces_to_remove, context='FACES')

  bm.to_mesh(duplicated_world.data)
  bm.free()

  logging.debug(f'{str(len(duplicated_world.data.polygons))} polys on carved mesh')

  target_origin = positioner.location
  world_matrix = duplicated_world.matrix_world
  local_origin = world_matrix.inverted() @ target_origin
  duplicated_world.data.transform(mathutils.Matrix.Translation(-local_origin))
  world_matrix.translation += (target_origin - world_matrix.translation)

  copy_normals_to_carved_tile(world, duplicated_world)

  return duplicated_world


def copy_normals_to_carved_tile(source_model : bpy.types.Object, tile_model : bpy.types.Object) -> None:
  tile_model.data.use_auto_smooth = True
  has_polygons = len(tile_model.data.polygons) > 0

  if has_polygons and False:
    modifier_name = 'Normals repair'

    data_transfer_modifier = tile_model.modifiers.new(modifier_name, 'DATA_TRANSFER')
    data_transfer_modifier.data_types_loops = {'CUSTOM_NORMAL'}
    data_transfer_modifier.loop_mapping = 'POLYINTERP_NEAREST'
    data_transfer_modifier.object = source_model

    context_override = bpy.context.copy()
    context_override['object'] = tile_model
    mod_result = bpy.ops.object.modifier_apply(context_override, modifier=modifier_name)
    assert('FINISHED' in mod_result)


def export(models : List[bpy.types.Object], output_path : str) -> None:
  logging.info(f'exporting to {output_path}...')

  context_override = bpy.context.copy()
  context_override['selected_objects'] = models

  bpy.ops.export_scene.fbx(
      context_override
    , filepath=output_path
    , apply_unit_scale=True
    , apply_scale_options='FBX_SCALE_ALL'
    , check_existing=False
    , axis_up='Y'
    , axis_forward='-Z'
    , use_selection=True
    , bake_space_transform=True
    , bake_anim=False
    , bake_anim_use_all_actions=False
  )


def index_of_first(collection : List[Any], pred : Callable[[Any], bool]) -> int:
  for index, value in enumerate(collection):
    if pred(value):
      return index

  return -1


def turn_on_loud_logging():
  logging.getLogger().addHandler(logging.StreamHandler())
  logging.getLogger().setLevel(logging.DEBUG)


if __name__ == '__main__':
  parser = ArgumentParser(description='Export a \'.blend\' tile file from art source to Unity source.')
  parser.add_argument('output_path', type=str, help='The path to export to')

  all_blender_args = sys.argv
  arg_separator_index = index_of_first(all_blender_args, lambda arg: arg == '--')
  if arg_separator_index == -1:
    logging.error('Blender was called with no arg separator (\'--\') so there was no way to know where this script\'s arguments began')
    sys.exit(-1)

  script_specific_args = all_blender_args[arg_separator_index + 1:]
  args = parser.parse_args(script_specific_args)
  
  pathlib.Path(args.output_path).parent.mkdir(parents=True, exist_ok=True)
  main(args.output_path)
