#! python

import os

import subprocess
from pathlib import Path

from voxel_collapse.eprint import *
from voxel_collapse.path import *


def export_blend_file(blend_file_path_str : str) -> None:
  blend_file_path = Path(blend_file_path_str)
  if not blend_file_path.exists():
    raise PathError(f'path "{blend_file_path_str}" does not exist')
  if not blend_file_path.is_file():
    raise PathError(f'path "{blend_file_path_str}" is not a file')
  if not blend_file_path.suffix == '.blend':
    eprint(f'path "{blend_file_path_str}" does not have a ".blend" extension, are you sure it\'s a Blender file? Continuing anyway')
  subprocess.run(['blender.exe', '--background', blend_file_path_str, '--python', str(blender_script_path), '--', calculate_export_path_for_blend_file(blend_file_path)])


def export_blend_3d_tile_file(blend_file_path_str : str) -> None:
  blend_file_path = Path(blend_file_path_str)
  if not blend_file_path.exists():
    raise PathError(f'path "{blend_file_path_str}" does not exist')
  if not blend_file_path.is_file():
    raise PathError(f'path "{blend_file_path_str}" is not a file')
  if not blend_file_path.suffix == '.blend':
    eprint(f'path "{blend_file_path_str}" does not have a ".blend" extension, are you sure it\'s a Blender file? Continuing anyway')
  subprocess.run(['blender.exe', '--background', blend_file_path_str, '--python', str(blender_tile_script_path), '--', calculate_export_path_for_blend_file(blend_file_path)])


script_directory_path = Path(__file__).parent.parent

relative_path_to_art_source = Path('..') / Path('Art')
art_source_path = (script_directory_path / relative_path_to_art_source).resolve()

relative_path_to_unity_source = Path('..') / Path('Assets')
unity_source_path = (script_directory_path / relative_path_to_unity_source).resolve()

relative_path_to_blender_script = Path('Blender') / Path('ExportToUnitySource.py')
blender_script_path = script_directory_path / relative_path_to_blender_script

relative_path_to_tile_blender_script = Path('Blender') / Path('Export3dTileToUnitySource.py')
blender_tile_script_path = script_directory_path / relative_path_to_tile_blender_script


def calculate_export_path_for_blend_file(blend_path : Path) -> Path:
  relative_path = blend_path.relative_to(art_source_path)
  return (unity_source_path / relative_path).with_suffix('.fbx')


def calculate_export_folder_path_for_blend_tile_file(blend_path : Path) -> Path:
  relative_path = os.path.basename(blend_path.relative_to(art_source_path))
  return (unity_source_path / relative_path)
